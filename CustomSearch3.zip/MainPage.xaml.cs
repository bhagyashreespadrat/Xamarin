﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace CustomSearch3
{
    public partial class MainPage : ContentPage
    {
        public List<Reading> ReadingList{ get; set; }
        public MainPage()
        {
            InitializeComponent();
            
            listView1.ItemsSource = GetBooks();
            ReadingList = new List<Reading>();
            ReadingList.Add(new Reading {ImageUrl = "water.png", Meter_No = "1234", Location = "Left side", Prev_Reading = "433", Current_Reading = "Enter Reading"});
            ReadingList.Add(new Reading {ImageUrl1= "fire.png", Meter_No1 ="234", Location1 ="Left side", Prev_Reading1= "2433", Current_Reading1 = "Enter Reading" });
            ReadingList.Add(new Reading {ImageUrl2 = "gas.png", Meter_No2 = "634", Location2 = "Left side", Prev_Reading2 = "33", Current_Reading2 = "Enter Reading" });         
            this.BindingContext = this;
        }
        private IEnumerable<Book> GetBooks(string searchText1 = null)
        {
            var books = new List<Book> {
                new Book{Customer="Name of Customer",Account=11-2222-33,Address="/12995 DFay Say Ft"},
                  new Book{Customer="Name of Customer",Account=22-3333-44,Address="/12995 DFay Say Ft"},
                    new Book{Customer="Name of Customer",Account=33-4444-55,Address="/12995 DFay Say Ft"},
                      new Book{Customer="Name of Customer",Account=44-5555-66,Address="/12995 DFay Say Ft"},
               };

            if (string.IsNullOrEmpty(searchText1))
                return books;
            return GetBooks().Where(p => p.Customer.ToLower().StartsWith(searchText1));
        }
       

        private void Btn_Clicked(object sender, EventArgs e)
        {
            this.searchTxt.Text = "";
        }
        private void SearchBar_TextChanged(object sender, TextChangedEventArgs e)
        {
            listView.ItemsSource = GetBooks(e.NewTextValue);
        }
        private void SearchBar_TextChanged1(object sender, TextChangedEventArgs e)
        {
            listView1.ItemsSource = GetBooks(e.NewTextValue);
        }

        private void OnTapGestureRecognizerTapped(object sender,EventArgs e)
        {
            Navigation.PushAsync(new CustPage());
        }
        public class Reading
        {           
            public string Meter_No { get; set; }
            public string Location { get; set; }
            public string Prev_Reading { get; set; }
            public string Current_Reading { get; set; }
            public string ImageUrl { get; set; }
            public string Meter_No1 { get; set; }
            public string Location1 { get; set; }
            public string Prev_Reading1 { get; set; }
            public string Current_Reading1 { get; set; }
            public string ImageUrl1 { get; set; }
            public string Meter_No2 { get; set; }
            public string Location2 { get; set; }
            public string Prev_Reading2 { get; set; }
            public string Current_Reading2 { get; set; }
            public string ImageUrl2 { get; set; }
        }
    }
}
