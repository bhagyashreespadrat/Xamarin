﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomSearch3
{
    public  class Book
    {
        public int Id { get; set; }
        public string Customer { get; set; }
        public int Account { get; set; }
        public string Address { get; set; }

    }
}
